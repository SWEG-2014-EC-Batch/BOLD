#include<iostream>
using namespace std;
int main(){
int i;
int k;
int r;
cout<<"Enter the number of row " ;
cin>>r;
for(i=1;i<=r;i++){
 for(k=1;k<=i;k++){ 
  cout<<"*";}
  cout<<endl;}
  return 0;}



