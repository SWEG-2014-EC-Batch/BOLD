#include<iostream>
using namespace std;
int main(){
int n,k,r;
cout<<"Enter the number of rows ";
cin>>r;
for(n=r;n>=1;n--){
  for(k=1;k<=n;k++){
      cout<<"*";}
      cout<<endl;}
    
    return 0;
}



