#include<iostream>
using namespace std;
int main(){
int n;
int i;
char ch;
for(i=1;i<=4;i++){
   for(char ch='a' ; ch<='e';ch++){
       cout<<ch<<" ";
   }
    cout<<endl;
}
   return 0;}
