#include<iostream>
using namespace std;
int main(){
int n;
int i;
for(n=1;n<=4;n++){
    for(i=1;i<=5;i++){
    cout<<i<<" " ; }
      cout<< endl; }
  return 0; 
}

