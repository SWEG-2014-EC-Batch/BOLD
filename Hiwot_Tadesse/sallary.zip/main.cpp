#include <iostream>
using namespace std;

int main()
{
    double grossSalary, workHours, pension, taxRate, tax, overtimeBonusRate = 0.0, overtimeHours = 0.0, netSalary;
    
    cout << "Enter gross salary: ";
    cin >> grossSalary;

    cout << "Enter work hours: ";
    cin >> workHours;

    if (workHours > 40.0)
    {
        cout << "Enter overtime bonus rate/hour: ";
        cin >> overtimeBonusRate;

        overtimeHours = workHours - 40.0;
    }

    cout << "Enter income tax rate (%): ";
    cin >> taxRate;
      pension = 0.07 * grossSalary;

    if (grossSalary <= 200)
    {
        taxRate = 0.0;
    }
    else if (grossSalary > 200 && grossSalary <= 600)
    {
        taxRate = 10.0;
    }
    else if (grossSalary > 600 && grossSalary <= 1200)
    {
        taxRate = 15.0;
    }
    else if (grossSalary > 1200 && grossSalary <= 2000)
    {
        taxRate = 20.0;
    }
    else if (grossSalary > 2000 && grossSalary <= 3500)
    {
        taxRate = 25.0;
    }
    else
 {
        taxRate = 30.0;
    }

    tax = (grossSalary - pension) * taxRate / 100.0;

    netSalary = grossSalary - pension - tax + (overtimeHours * overtimeBonusRate);

    cout << "Net salary: " << netSalary << endl;

    return 0;
}